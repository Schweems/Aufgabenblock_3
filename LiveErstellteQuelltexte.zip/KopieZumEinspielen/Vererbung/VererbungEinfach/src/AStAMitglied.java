
public class AStAMitglied extends Studierende {
   private String welcheFachschaft;
   
   public AStAMitglied(String vorname, String nachname, 
		     int matnr, String welcheFachschaft ) {
	   super(vorname,nachname,matnr);
	   
	   this.welcheFachschaft = welcheFachschaft;
   }
   
}
