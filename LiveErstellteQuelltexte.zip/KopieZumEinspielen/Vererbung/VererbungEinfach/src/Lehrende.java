// Klasse Studierende erweitert Klasse Person
// um einige Eigenschaften -- erbt von Person
public class Lehrende extends Person {
	private int persnr;
	
	public Lehrende(String vorname, String nachname, int persnr) {
		super(vorname,nachname);// Aufruf ererbter Superklassen-Konstruktor aus Person
		this.persnr = persnr;
		System.out.println("Konstruktor Studierende fertig!");
	}
	
	public int getPersnr() {
		return this.persnr;
	}
	

}
