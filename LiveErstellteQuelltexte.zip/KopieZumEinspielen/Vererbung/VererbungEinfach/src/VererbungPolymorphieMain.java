
public class VererbungPolymorphieMain {

	public static void main(String[] args) {
		// Es gibt hier Personen unterschiedlicher Ausgestaltung
		// --> Polymorphie = Vielgestaltigkeit
		Person p0 = new Person("Erna","Etepetete");
		Person p1 = new Studierende("Hans","Meier",4711);
		Person p2 = new Lehrende("Ute","Matecki",876544);
		
		int matnr = ((Studierende)p1).getMatnr();

	}

}
