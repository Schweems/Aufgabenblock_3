
public class VererbungMain {

	public static void main(String[] args) {
		Person erna = new Person("Erna","Etepetete");
		Studierende hans = new Studierende("Hans","Meier",4711);

	}

}
