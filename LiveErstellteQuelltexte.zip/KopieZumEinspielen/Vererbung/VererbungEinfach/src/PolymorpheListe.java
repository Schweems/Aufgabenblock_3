import java.util.*;
public class PolymorpheListe {

	public static void main(String[] args) {
		// ArrayList fuer alle Arten  von Personen
		ArrayList<Person> personen = new ArrayList<Person>();
		
		Scanner tastatur = new Scanner(System.in);
		
		System.out.print("Wie viele? ");
		int anzahl = tastatur.nextInt();
		Person pers = null;
		
		for (int i=0; i< anzahl; i++) {
			System.out.print("Person/Studierende? ");
			String clazz = tastatur.next();
			
			System.out.print("Vorname: ");
			String vor = tastatur.next();
			
			System.out.print("Nachname: ");
			String nach = tastatur.next();
			
			switch(clazz) {
			case "Person": 	pers = new Person(vor,nach);
							personen.add(pers); break;
							
			case "Studierende": 
				System.out.print("Matnr: ");
				int matnr = tastatur.nextInt();
				pers = new Studierende(vor,nach,matnr);
				personen.add(pers);
			default: break;
			
			}// end switch
		} // end for
		
		for (Person p : personen) {
			String clazzname = p.getClass().getName();
			System.out.println("Class: " + clazzname);
		}

		tastatur.close();
	}

}
