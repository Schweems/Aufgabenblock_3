// Klasse Studierende erweitert Klasse Person
// um einige Eigenschaften -- erbt von Person
public class Studierende extends Person {
	private int matnr;
	
	public Studierende(String vorname, String nachname, int matnr) {
		super(vorname,nachname);// Aufruf ererbter Superklassen-Konstruktor aus Person
		this.matnr = matnr;
		System.out.println("Konstruktor Studierende fertig!");
	}
	
	public int getMatnr() {
		return this.matnr;
	}
	
	@Override
	public void print() {
		super.print(); // ererbte print()-Methode zuerst aufrufen
		System.out.println("Meine Matrikelnr: " + matnr); // dann matnr ausgeben
	}
	
	@Override
	public void print(String gruss) {
		super.print(gruss); // ererbte print()-Methode zuerst aufrufen
		System.out.println("Meine Matrikelnr: " + matnr); // dann matnr ausgeben
	}
	
	@Override
	public String toString() {
		String s = "{" + getVorname() + "," + getNachname() + "," +matnr + "}";
		return s;
	}
 
}
