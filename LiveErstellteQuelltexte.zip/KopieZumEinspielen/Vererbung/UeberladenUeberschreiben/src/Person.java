
public class Person {
	private String vorname;
	private String nachname;
	
	public Person(String vorname, String nachname) {
		this.vorname = vorname;
		this.nachname = nachname;
		System.out.println("Konstruktor Person fertig!");
	}
	
	public String getVorname() { return this.vorname; }
	public String getNachname() {return this.nachname; }
	public void setVorname(String vorname) {this.vorname = vorname; }
	public void setNachname(String nachname) {this.nachname = nachname; }
	
	// Ueberladen von Methode print()
	public void print() {
		System.out.println("Ich heisse:");
		System.out.println("Vorname: " + vorname);
		System.out.println("Nachname: " + nachname);
	}
	
	public void print(String gruss) {
		System.out.println(gruss + ", ich heisse:");
		System.out.println("Vorname: " + vorname);
		System.out.println("Nachname: " + nachname);
	}
	
	@Override
	public String toString() {
		String s= "{" + vorname + "," + nachname + "}";
		return s;
	} 
	

}
