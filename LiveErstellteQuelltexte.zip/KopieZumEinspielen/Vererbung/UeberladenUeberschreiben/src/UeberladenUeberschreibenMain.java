
public class UeberladenUeberschreibenMain {

	public static void main(String[] args) {
		Person p = new Studierende("Hans","Meier",5678);
		Person q = new Person("Hugo","Helmchen");
		
		p.print("Hallo");// Aufruf der ueberschreibenden Methode
		System.out.println("---------");
		q.print("Servus");
		System.out.println("---------");
		System.out.println("p: " + p);
		System.out.println("q: " +q);
		System.out.printf("Letzte Ausgabe: %s",q);

	}

}
