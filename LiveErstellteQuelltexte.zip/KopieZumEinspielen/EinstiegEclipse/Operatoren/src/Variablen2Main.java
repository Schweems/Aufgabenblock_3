
public class Variablen2Main {
  public static void main(String [] args) {
    
    Variablen2 worker = new Variablen2();
    worker.methode1(42);
    worker.methode2();
    worker.methode3();
  } // end method main()
} // end class
