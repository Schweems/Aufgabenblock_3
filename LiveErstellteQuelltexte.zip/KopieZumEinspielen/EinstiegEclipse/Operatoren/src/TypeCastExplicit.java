
public class TypeCastExplicit {

	public static void main(String[] args) {
		short a=50;
		short b=70;
		short c=1000;
		
		short ergebnis1 = (short)(a * b);
		// Ergebnis: 3500 -- ok!
		System.out.println("erg1: " + ergebnis1);
		
		// Fies: vordere 2 Bytes werden abgehackt!
		short ergebnis2 = (short)(b * c);
		System.out.println("erg2: " + ergebnis2);
		
		a = (short)(a + 50000);
		
	}

}
