
public class TypeCastImplicit {

	public static void main(String[] args) {
		short var1 = 20000;
		short var2 = 5;
		byte a=5;
		byte b=10;
		double x = 5.5;
		
		int c = a * b;
		
		int var = var1 * var2;
		double y = a * x;
		long lvar = var * 20000L;
		
	}

}
