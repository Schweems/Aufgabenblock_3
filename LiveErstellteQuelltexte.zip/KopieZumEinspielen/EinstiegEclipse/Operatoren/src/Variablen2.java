
public class Variablen2 {
  
  // Objektvariable:
  // wirkt innerhalb der Methoden
  // dieser Klasse "global"
  int variable=100;
  
  void methode1(int variable) {
    
    // lokale Variable!
    // ueberlagert Objektvariable
    // oben!
    variable = 5000;
    
    System.out.println("variable: "+variable);
  }
  
  void methode2() {
    // lokale Variable!
    // ueberlagert Objektvariable
    // oben!
    int variable = -2;
    
    System.out.println("variable: "+ variable);
  }
  
  void methode3() {
    // Hier gibt es keine lokalen Variablen
    // --> Objektvariable oben wird ausgegeben!
    System.out.println("variable: "+variable);
  }

}
