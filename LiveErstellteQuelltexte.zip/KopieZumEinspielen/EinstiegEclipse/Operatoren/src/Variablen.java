
public class Variablen {
	
	public static void main(String [] args) {
		int wert1=1000; // In Java wird IMMER explizit typisiert
		double wert2=25.5;
		byte bWert=55;
		short shWert=10000;
		long lWert=100000000000L;
		char c='A'; // Hochkommas auf der deutschen Tastatur auf Shift #
		String str="Hugo";
		boolean x=false;
		float fWert=2.5f;
		final double PI_NEU=3.14159;// Konstanten werden mit final gekennzeichnet
		// double wert1=5.5; // Das geht in Java NICHT!
		
		wert1=5000;
		System.out.println("Wert1: " +wert1);
		System.out.println("Wert c: " +c);
		System.out.println("Wert x: " +x);
	
	}

}
