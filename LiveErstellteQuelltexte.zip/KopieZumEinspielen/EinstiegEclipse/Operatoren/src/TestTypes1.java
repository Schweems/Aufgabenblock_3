
public class TestTypes1 {

	public static void main(String[] args) {
		int iWert1, iWert2, iWert3;
		double dWert1;
		byte bWert1;
		short shWert1 = 25000;
		
		// 1. Welchen Wert enthaelt bWert1 nach diesen
		// Anweisungen? Begruenden Sie bitte Ihre Antwort!
		bWert1 = 7;    // 0000 0111
		bWert1 += 231; 
		System.out.println("bWert1: " + bWert1); // 1110 0111 --> -18!!!
		
		// Fies: 1/3 = 0, da ganzzahlig. 0*25000 = 0. 0 + 0.2 = 0.2
		dWert1 = 1/3 * shWert1 + 0.2;
		System.out.println("dWert1: " + dWert1);
		
		// 5. Welchen Wert enthalten swWert1, iWert2 und bWert1 nach diesen Anweisungen?
		// Begruenden Sie bitte Ihre Antwort!
		shWert1 = 8;
		bWert1 = 2;
		iWert2 = --shWert1 + bWert1++;
		System.out.println("shWert1: " + shWert1 + " bWert1: " 
		                          + bWert1 + " iWert2: " + iWert2);
		
		// 7. Welchen Wert enthaelt iWert2 nach diesen
		// Anweisungen? Begruenden Sie bitte Ihre Antwort!
		iWert1 = -5;
		iWert2 = iWert1 >>> 3;
		System.out.println("iWert2: " + iWert2);
		
		// 8. Welchen Wert enthaelt iWert3 nach diesen
		// Anweisungen? Begruenden Sie bitte Ihre Antwort!
		iWert1 = 34;
		iWert2 = 989;
		iWert3 = iWert1 | iWert2;
		System.out.println("iWert3: " + iWert3);

	}

}
