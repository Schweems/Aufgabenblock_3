
public class ShiftOps {

	public static void main(String[] args) {
		// 0000 0000 0000 0000 0000 0000 0000 1111
		int a=0x0F;
		//
		int x=-15;// Schiebt bei neg. Zahlen links 1sen nach --> vorzeichenerhaltend
		
		int b = a >> 2; // ... 0011
		System.out.println("b: " + b);
		
		int c = a >> 1; // ... 0111 // Schiebt bei pos. Zahlen links 0sen nach --> vorzeichenerhaltend
		System.out.println("c: " + c);
		
		int d = a << 1;
		System.out.println("d: " + d);
		
		int e = x >> 1; // Schiebt bei neg. Zahlen links 1sen nach --> vorzeichenerhaltend
		System.out.println("e: " + e);
		
		int f = x >>> 1; // Schiebt links eine 0 nach --> vorzeichenlos
		System.out.println("f: " + f);
		int g = 299955 >> -1; //
		System.out.println("g: " + g);
	  
		

	}

}
