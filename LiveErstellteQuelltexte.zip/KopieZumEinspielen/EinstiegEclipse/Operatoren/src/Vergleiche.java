
public class Vergleiche {

	public static void main(String[] args) {
		int a=5;
		int b=7;
		int x=2;
		
		boolean test = a < b;
		System.out.println("test: " + test);
		
		if (test) {
			System.out.println("a < b!");
		}
		else {
			System.out.println("NICHT a < b!");
		}
		
		if ( x > 10 && x < 20) {  // 10 < x < 20
			System.out.println("Im Intervall!");
		}
		else {
			System.out.println("NICHT im Intervall!");
		}
		
		if (x < 10 || x == 5) {
			System.out.println("Erfuellt!");
		}
		else {
			System.out.println("Nicht Erfuellt!");
		}

	}

}
