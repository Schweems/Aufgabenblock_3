
public class OperatorTest {

	public static void main(String[] args) {
		int a=5;
		int b=7;
		
		int c = a+b-10;
		System.out.println("c: " + c);
		
		// a = a * 2;
		a *= 2;
		System.out.println("a: " +a);
		
		b %= 2; // b = b % 2;
		System.out.println("b: " + b);

	}

}
