
public class IncDecSimple {

	public static void main(String[] args) {
		int a=5;
		int b=8;
		
		// a = a +1;
		a++;
		System.out.println("a: " + a);
		// b = b + 1;
		++b;
		System.out.println("b: " +b);

	}

}
