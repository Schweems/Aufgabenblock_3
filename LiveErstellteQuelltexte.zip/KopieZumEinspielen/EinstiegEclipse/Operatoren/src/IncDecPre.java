
public class IncDecPre {

	public static void main(String[] args) {
		int a=5;
		int b=99;
		
		int c = ++a + 10;
		int d = --b + 100;
		System.out.println("a: " + a +" c: "+ c);
		System.out.println("b: " + b +" d: "+ d);
	}

}
