
public class BitOps {

	public static void main(String[] args) {
		// 0000 0000 0000 0000 0000 0000 0000 0111
		int a=7;
		// 0000 0000 0000 0000 0000 0000 0000 0101
		int b=5;
	    
		//d = 0000 0000 0000 0000 0000 0000 0000 0101
		int c = a & b;
		System.out.println("c: " + c);
		
		// d = 0000 0000 0000 0000 0000 0000 0000 0111
		int d = a | b;
		
		// e = 0000 0000 0000 0000 0000 0000 0000 0010
		int e = a ^ b;
		
		// f = 1111 1111 1111 1111 1111 1111 1111 1000
		int f = ~a;
		System.out.println("f: " +f);
		
		int g = ~(a | b);
		System.out.println("g: " + g);
		

	}

}
