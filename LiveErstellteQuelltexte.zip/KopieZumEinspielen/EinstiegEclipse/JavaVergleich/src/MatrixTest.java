
public class MatrixTest {

	public static void main(String[] args) {
		int rows=3;
		int cols=5;
		
		int [][] matrix1 = new int[rows][cols];
		int i=2;// Zeile
		int j=3;// Spalte
		
		matrix1[i][j]=255;
		
		double [][] matrix2 = new double[rows][cols];
		matrix2[i][j]=199.75;

	}

}
