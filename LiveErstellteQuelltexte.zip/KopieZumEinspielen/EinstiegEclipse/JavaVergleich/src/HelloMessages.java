
public class HelloMessages {
	
	String nachricht;
	
	// Konstruktor: Standardkonstruktor
	// wird von new aufgerufen
	HelloMessages(){
	
		nachricht="Moin!";
	}
	
	HelloMessages(String nachricht){
		this.nachricht = nachricht;
	}
	
	void hello() {
		System.out.println(nachricht);
	}

}
