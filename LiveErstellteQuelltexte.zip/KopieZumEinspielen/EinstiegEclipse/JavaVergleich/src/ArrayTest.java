
public class ArrayTest {

	public static void main(String[] args) {
		int [] array1 = new int[3]; // Speicher wird auf dem Freispeicher (Heap) reserviert
		int [] array2 = {22,33,67,54}; // Speicher wird auf dem Stack DIESER Methode reserviert
		
		array1[0]=44;
		array1[1]=2;
		array1[2]=9;
		
		System.out.println("Laenge von array2: " + array2.length);
		System.out.println("Wert array1[0]: " + array1[0]);
		
		int i=1;
		System.out.println("Wert array1[i]: " + array1[i]);
		System.out.println("Wert array2[1]: " + array2[1]);
		array2[1]=99;
		System.out.println("Wert array2[1]: " + array2[1]);
		

	}

}
