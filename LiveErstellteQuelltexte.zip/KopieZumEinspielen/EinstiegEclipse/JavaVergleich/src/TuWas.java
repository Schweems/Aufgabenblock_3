
public class TuWas {

	// Kein selbst gebauter Konstruktor
	// --> Java erzeugt hier einen unsichtbaren Standard-Konstruktor
	void ichTueWas() {
		System.out.println("Ich tue so, als ob ich arbeite.");

	}

}
