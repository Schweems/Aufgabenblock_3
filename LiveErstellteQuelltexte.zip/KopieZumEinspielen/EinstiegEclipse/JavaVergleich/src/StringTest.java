
public class StringTest {

	public static void main(String[] args) {
		String s1="Erna";
		
		int alter=20;
		
		String s2 = s1 + " ist " + alter + " Jahre alt.";
		System.out.println(s2);
		System.out.println(s1 + " faehrt gern Motorrad!");

	}

}
