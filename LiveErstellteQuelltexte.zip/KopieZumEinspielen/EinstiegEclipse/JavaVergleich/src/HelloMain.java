
public class HelloMain {

	public static void main(String[] args) {
		// Parameterloser Konstruktor
		HelloMessages worker1 = new HelloMessages();
		HelloMessages worker2 = new HelloMessages("HalliHallo!");
		// Methode aufrufen
		worker1.hello();
		
		// Variable nachricht direkt zugreifen
		System.out.println("Nachricht aus worker1: " + worker1.nachricht);
		//worker2.nachricht = "Servus!";
		
		worker2.hello();
		worker1.hello();
		
		TuWas tuwas=new TuWas();
		tuwas.ichTueWas();
		

	}

}
