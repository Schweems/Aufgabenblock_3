
public class TesteNull {

	public static void main(String[] args) {
		int [] arr1=null;
		
		//arr1[0] = 5;
		arr1 = new int[2];
		arr1[0] = 5;
		System.out.println("Fertig!" + arr1[0]);

	}

}
