import java.util.Scanner;

public class TesteNullMitEingabe {

	public static void main(String[] args) {
		int [] arr = null;
		
		// Eingabe von Werten mit Scanner-Objekt
		Scanner eingabe = new Scanner(System.in);
		
		System.out.print("Wieviel Elemente? ");
		int anzahl = eingabe.nextInt();
		System.out.println("Eingabe war: " +anzahl);
		arr = new int[anzahl];
		
		if ( arr != null) {
			System.out.println("Wertzuweisung an arr[0]: ");
			arr[0]=99;
		}
		
		System.out.print("Wie heissen Sie?");
		String name = eingabe.next();
		System.out.println("Hallo " + name);
		System.out.print("Jahresgehalt: ");
		double gehalt = eingabe.nextDouble();
		System.out.println("Eingabe war: " + gehalt);
	}

}
