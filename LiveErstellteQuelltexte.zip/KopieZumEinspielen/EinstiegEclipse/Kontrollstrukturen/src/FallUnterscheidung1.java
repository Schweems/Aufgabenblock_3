import java.util.Scanner;
public class FallUnterscheidung1 {

	public static void main(String[] args) {
		Scanner eingabe = new Scanner(System.in);
		System.out.print("Ganzzahl: ");
		int wert = eingabe.nextInt();
		
		if (wert >= 0 && wert <= 5) {
			System.out.println("Zwischen 0 und 5");
		}
		else if (wert >= 0 && wert <= 10) {
			System.out.println("0 bis 10");
		}
		
		
		eingabe.close();

	}

}
