import java.util.Scanner;
public class FallUnterscheidung2 {

	public static void main(String[] args) {
		Scanner eingabe = new Scanner(System.in);
		System.out.print("Ganzzahl: ");
		int wert = eingabe.nextInt();
		
		if (wert == 1 || wert == 2) {
			System.out.println("1 oder 2");
		}
		else if (wert == 3) {
			System.out.println("drei");
		}
		
		
		eingabe.close();

	}

}
