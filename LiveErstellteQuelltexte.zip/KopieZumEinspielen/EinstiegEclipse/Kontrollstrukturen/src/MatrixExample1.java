
public class MatrixExample1 {
	
	int [][] chessMatrix(int rows, int cols){
		int [][] matrix = new int[rows][cols];
		// ganz viel dazwischen
		for (int i=0; i<matrix.length; i++) {
			for(int j=0; j< matrix[i].length; j++) {
				//matrix[i][j] = 5;
				if ( (i%2 == 0 && j %2 == 0) || (i%2 == 1 && j%2 == 1) ) {
					matrix[i][j] = 0;
				}
				else {
					matrix[i][j] = 255;
				}
				
			}
		}
		return matrix;
	}
	
	void printMatrix(int [][] matr) {
		for (int i=0; i< matr.length; i++) {
			for (int j=0; j<matr[i].length; j++) {
				System.out.print(matr[i][j] + "\t");
			}
			System.out.println();
		}
	}

}
