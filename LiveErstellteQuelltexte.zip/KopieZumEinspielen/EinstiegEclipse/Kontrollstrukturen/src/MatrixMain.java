
public class MatrixMain {

	public static void main(String[] args) {
		int [][] mat=null;
		MatrixExample1 worker =
				new MatrixExample1();
		int rows = 4;
		int columns = 5;
		mat = worker.chessMatrix(rows, columns);
		worker.printMatrix(mat);

	}

}
