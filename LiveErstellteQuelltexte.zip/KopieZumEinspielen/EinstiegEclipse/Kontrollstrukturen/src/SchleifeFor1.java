import java.util.Scanner;
public class SchleifeFor1 {

	public static void main(String[] args) {
		Scanner eingabe = new Scanner(System.in);
		System.out.print("Maximum: ");
		
		int max = eingabe.nextInt();
		for(int i=0; i < max; i+=2) {
			System.out.println("i: " +i);
		}
		
		System.out.print("Minimum: ");
		int min = eingabe.nextInt();
		for (int k = max; k > min; k--) {
			System.out.println("Neues k: " +k);
		}
		System.out.println("Fertig!");
		eingabe.close();

	}

}
