import java.util.Scanner;

public class SchleifeDoWhile {

	public static void main(String[] args) {
		Scanner eingabe = new Scanner(System.in);
		int zahl;
		
		do {
			System.out.print("Eingabe: ");
			zahl = eingabe.nextInt();
			
		}while (zahl >= 1 && zahl <= 10);
		System.out.println("Schleife beendet");
		
		
		eingabe.close();
	}

}
