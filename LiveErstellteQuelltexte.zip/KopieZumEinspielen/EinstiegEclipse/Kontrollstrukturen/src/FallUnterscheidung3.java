import java.util.Scanner;
public class FallUnterscheidung3 {

	public static void main(String[] args) {
		Scanner eingabe = new Scanner(System.in);
		System.out.print("Ganzzahl: ");
		int wert = eingabe.nextInt();
		
		switch(wert) {
			case 1: System.out.println("Das war ne 1");
					System.out.println("Wir inkrementieren");
					wert++;
					System.out.println("Und jetzt: " +wert); break;
			
			case 5: 
			case 8:
			case 9: System.out.println("Gewuenschte Zahl!"); break;
			default: System.out.println("Nix davon!"); break;
		}
		
		
		eingabe.close();

	}

}
