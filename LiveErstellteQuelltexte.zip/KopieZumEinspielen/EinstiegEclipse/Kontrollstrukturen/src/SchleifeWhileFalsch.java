
public class SchleifeWhileFalsch {

	public static void main(String[] args) {
		int wert = 10;
		int i=0;
		while(i < wert) 
			; 
		
		
		{
			i++;
			System.out.println("i: "+ i);
		}

	}

}
