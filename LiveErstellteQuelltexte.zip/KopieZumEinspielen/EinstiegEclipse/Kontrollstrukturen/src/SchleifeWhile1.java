import java.util.Scanner;
public class SchleifeWhile1 {

	public static void main(String[] args) {
		Scanner eingabe = new Scanner(System.in);
		System.out.print("Erste Ganzzahl: ");
		int wert = eingabe.nextInt();
		
		while ( wert >= 0 && wert <= 10) {
			System.out.print("Ganzzahl: ");
			wert = eingabe.nextInt();
		}
		System.out.println("Fertig!");
		eingabe.close();

	}

}
