
public class SchleifeFor2 {

	public static void main(String[] args) {
		int [] zahlen = {32,45,-12,-10};
		String [] namen = {"obelix","asterix","majestix","gutemine"};
		System.out.println("Laenge: " + zahlen.length);
		
		for (int i=0; i<zahlen.length; i++) {
			System.out.println("Platz " + i + ":" + zahlen[i]);
		}
		
		for(int wert : zahlen) {
			System.out.println("Naechster: " + wert);
		}
		
		for(String str : namen) {
			System.out.println("Bewohner: " + str);
		}

	}

}
