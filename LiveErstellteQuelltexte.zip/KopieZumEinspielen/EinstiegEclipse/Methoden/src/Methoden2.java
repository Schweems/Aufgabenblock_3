
public class Methoden2 {
	
	void testMethode1(Person p) {
		p.ausgabe();
		p.name = "Genoveva";
	}
	
	double testMethode2(double m, double x, double b) {
		x = m * x + b;
		
		return x;
	}

}
