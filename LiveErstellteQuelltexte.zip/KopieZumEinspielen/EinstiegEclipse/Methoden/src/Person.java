
public class Person {
	
	String name;
	
	Person(String name) {
		this.name = name;
	}
	
	void ausgabe() {
		System.out.println("Ich heisse: " + name);
	}

}
