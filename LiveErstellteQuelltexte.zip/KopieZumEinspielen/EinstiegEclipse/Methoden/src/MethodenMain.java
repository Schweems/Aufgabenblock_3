
public class MethodenMain {

	public static void main(String[] args) {
		String n = "Hugo";
		SagHallo worker = new SagHallo();
		worker.sagHallo(n);
		
		int wahlAlter = worker.altersBerechnung(22);
		System.out.println("Sie duerfen seit "+ wahlAlter + " Jahren waehlen!");

	}

}
