
public class SagHallo {
	
	void sagHallo(String name) {
		System.out.println("Hallo " + name);
	}
	
	int altersBerechnung(int alter) {
		int ergebnis = alter - 18;
		return ergebnis;
	}

}
