
public class Methoden2Main {

	public static void main(String[] args) {
		Methoden2 worker = new Methoden2();
		double mNeu = 2.0;
		double xNeu = 1.5;
		double bNeu = 0.5;
		Person pers = new Person("Erna");
		
		double erg = worker.testMethode2(mNeu, xNeu, bNeu);
		System.out.println("Ergebnis: " + erg);
		System.out.println("xNeu: " + xNeu);
		
		worker.testMethode1(pers);
		pers.ausgabe();
		

	}

}
