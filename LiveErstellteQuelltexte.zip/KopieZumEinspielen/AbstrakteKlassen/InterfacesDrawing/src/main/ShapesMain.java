package main;
import io.Drawing;

public class ShapesMain {

	public static void main(String[] args) {
		Drawing d1 = new Drawing();
		d1.read();
		d1.write();
		d1.read();
		
	}

}
