package io;

public interface IShapeReader {
	
	// Shapes aus irgendeiner Datenquelle einlesen
	public void read();

}
