package io;
import java.util.*;

import shapes.*;

public class Drawing  implements 
   IShapeReader, IShapeWriter 
     {
	private ArrayList<Shape> myShapes;
	private Scanner tastatur;
	public Drawing() {
		// Leere Liste erzeugen
		myShapes = new ArrayList<Shape>();
		tastatur = new Scanner(System.in);
	}
	
	@Override
	public void write() {
		/*for (Shape s : myShapes) {
			s.print();
		}*/
		for (int i=0; i< myShapes.size(); i++) {
			Shape s = myShapes.get(i);
			s.print();
		}
	}

	@Override
	public void read() {
		
		String eingabe = "";
		String identifier;
		int x,y;
		Shape s = null;
		do {
			System.out.print("Welche Objektart? ");
			eingabe = tastatur.next();
			if (eingabe.equals("Point") || eingabe.equals("Circle")  ) {
				// Gemeinsame Eigenschaften eingeben
				System.out.print("Bezeichner: ");
				identifier = tastatur.next();
				System.out.print("x: ");
				x = tastatur.nextInt();
				System.out.print("y: ");
				y = tastatur.nextInt();
				
				switch (eingabe) {
				case "Point" :
					s = new Point(identifier,x,y);
					break;
					
				case "Circle" : 
					System.out.print("Radius: ");
					int radius = tastatur.nextInt();
					s = new Circle(identifier,x,y,radius);
					
					break;
				}
				myShapes.add(s); // Shape in Liste haengen
				
			}
			System.out.print("weiter/ende?");
			eingabe = tastatur.next();
		}while (!eingabe.equals("ende"));	
		
	} // end method read()

}
