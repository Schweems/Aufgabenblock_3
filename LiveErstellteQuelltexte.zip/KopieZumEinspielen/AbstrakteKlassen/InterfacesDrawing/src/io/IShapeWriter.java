package io;

public interface IShapeWriter {
	
	// Shapes in irgendeine Datensenke schreiben.
	public void write();

}
