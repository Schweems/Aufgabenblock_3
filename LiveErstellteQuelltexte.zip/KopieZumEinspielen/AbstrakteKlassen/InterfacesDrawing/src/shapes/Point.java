package shapes;
public class Point extends Shape{
	
	private int x;
	private int y;
	
	public Point(String identifier, int x, int y) {
		super(identifier);
		this.x = x;
		this.y = y;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	@Override
	public void print() {
		System.out.println("Identifier: " + this.getIdentifier());
		System.out.println("x= " + x +"; y= "+y);
	}
	

}
