package shapes;
public abstract class Shape {
	
	private String identifier;

	public Shape(String identifier) {
		this.identifier = identifier;
	}
	
	public String getIdentifier() {
		return this.identifier;
	}
	
	public abstract void print();
}
