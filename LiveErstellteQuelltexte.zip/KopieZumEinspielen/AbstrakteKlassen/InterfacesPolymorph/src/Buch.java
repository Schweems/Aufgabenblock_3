
public interface Buch {
	
	
	public abstract String toString();

}
