
public class Sachbuch implements Buch {

	private String thema;
	public Sachbuch(String thema) {
		this.thema = thema;
	}

	@Override
	public String toString() {
		return "Sachbuch mit dem Thema: " +thema;
	}
}
