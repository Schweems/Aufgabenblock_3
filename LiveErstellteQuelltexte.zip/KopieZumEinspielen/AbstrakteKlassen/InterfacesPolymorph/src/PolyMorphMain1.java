import java.util.*;
public class PolyMorphMain1 {
    public static void ausgabe(Buch b) {
    	
    	if ( b instanceof Sachbuch) {
    		System.out.println(b + "ist Sachbuch!") ;
    	}
    	else if (b instanceof Roman) {
    		System.out.println(b + " ist ein Roman!");
    	}
    	else {
    		System.out.println("Weder Roman noch Sachbuch");
    	}
    }
	
	public static void main(String[] args) {
		Buch b = new Sachbuch("Programmieren mit viel Koffein und Chips");
		ArrayList<Buch> bList = new ArrayList<Buch>();
		bList.add(b);
		bList.add(new Roman("Gruseln beim Vererben"));
		//bList.add(new Roman());
		/*Scanner s =new Scanner(System.in);
		System.out.print("Sachbuch oder Roman? ");
		String eingabe = s.nextLine();
		System.out.print("Titel: ");
		String titel = s.nextLine();
		Buch b = null;
		switch(eingabe) {
		case "Roman": b = new Roman(titel); break;
		case "Sachbuch": b = new Sachbuch(titel); break;
		}
		
		PolyMorphMain1.ausgabe(b);*/
		
		
	}

}
