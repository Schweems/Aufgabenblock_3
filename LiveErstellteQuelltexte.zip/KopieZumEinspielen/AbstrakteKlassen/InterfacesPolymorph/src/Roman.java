
public class Roman implements Buch {
	private String titel;
	public Roman(String titel) {
		this.titel = titel;
	}

	@Override
	public String toString() {
      return "Roman Titel: " +titel;
	}

}
