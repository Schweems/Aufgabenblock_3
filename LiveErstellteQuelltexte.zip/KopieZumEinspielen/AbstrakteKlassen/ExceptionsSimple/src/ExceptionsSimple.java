
public class ExceptionsSimple {

	public static void main(String[] args) {
		int [] arr = {12,-7,100};
		// laeuft einen Platz zu weit
		for (int i=0; i <= 3; i++) {
			System.out.println("Wert: " +arr[i]);
		}
		// Abbruch vorher mit Exception
		System.out.println("Fertig!");

	}

}
