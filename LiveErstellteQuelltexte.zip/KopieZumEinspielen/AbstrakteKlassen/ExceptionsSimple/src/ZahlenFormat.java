
public class ZahlenFormat {
	
	public int returnZahlWert(char ziffer)
	          throws NumberFormatException {
		// ist in Wirklichkeit 48 <= ziffer <= 57
		if (ziffer >= '0' && ziffer <= '9') {
			return ziffer - '0';
		}
		else {
			NumberFormatException e =
					new NumberFormatException(ziffer + " ist keine Ziffer!");
			throw e;
		} // end else
		
	} // end method
	
	public boolean isInt(String s) {
		try {
			Integer.parseInt(s);
			return true;
		}
		catch(NumberFormatException e) {
			return false;
		}
		
	}

}
