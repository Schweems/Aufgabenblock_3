import java.util.*;
public class MainExceptions {

	public static void main(String[] args) {
		Scanner tastatur = new Scanner(System.in);
		ZahlenFormat worker = new ZahlenFormat();
		System.out.print("String eingeben: ");
		String test = tastatur.nextLine();
		if (worker.isInt(test)) {
			System.out.println("War ein int!");
		}
		else {
			System.out.println("War KEIN int!");
		}
		
		
		System.out.print("Ziffer zwischen 0 und 9: ");
		String s = tastatur.nextLine();
		
		
		try {
		  char c = s.charAt(0);
		  int wert = worker.returnZahlWert(c);
		  System.out.println("Zahlwert war: " +wert);
		}
		
		catch(NumberFormatException e) {
			System.err.println("Das war keine Ziffer!");
			e.printStackTrace();
		}
		catch(StringIndexOutOfBoundsException e) {
			System.out.println("String war leer!");
			e.printStackTrace();
		}
		catch(Exception e) {
			System.out.println("Anderer Unsinn!");
			e.printStackTrace();
		}
		finally {
		  System.out.println("jetzt wirklich fertig!");
		}

	}

}
