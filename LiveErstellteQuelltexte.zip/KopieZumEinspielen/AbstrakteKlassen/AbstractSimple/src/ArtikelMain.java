import java.util.*;


public class ArtikelMain {

	public static void main(String[] args) {
		
		
		VerarbeiteArtikel worker = new VerarbeiteArtikel();
		Locale.setDefault(Locale.ENGLISH);
		Scanner tastatur = new Scanner(System.in);
		ArrayList<Artikel> liste = worker.einlesen(tastatur);
		worker.ausgeben(liste);
		tastatur.close();
	}

}
