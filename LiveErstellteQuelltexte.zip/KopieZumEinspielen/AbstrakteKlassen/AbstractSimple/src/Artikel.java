
public abstract class Artikel {
	
  private String artikelName;
  private int artikelNummer;
  
  public Artikel(String artikelName, int artikelNummer) {
	  this.artikelName = artikelName;
	  this.artikelNummer = artikelNummer;
  }
  
  public void setArtikelName(String artikelName) { this.artikelName = artikelName;}
  public void setArtikelNummer(int artikelNummer) {this.artikelNummer = artikelNummer;}
  public String getArtikelName() {return this.artikelName;}
  public int getArtikelNummer() {return this.artikelNummer;}
  
  @Override
  public String toString() {
	  String s = "[" + artikelName + " " + artikelNummer + "]";
	  return s;
  }
  public abstract void print() ;
  
}
