// Abstrakte Klasse
public abstract class BuchungsService {
	private String anbieter;
	
	public BuchungsService(String anbieter) {
		this.anbieter = anbieter;
	}
	
	public String getAnbieter() {
		return anbieter;
	}
	// Diese Methoden koennen erst in
	// konkreten Service-Klassen implementiert
	// werden
	public abstract double preis();
	
	public abstract String rechnung();

}
