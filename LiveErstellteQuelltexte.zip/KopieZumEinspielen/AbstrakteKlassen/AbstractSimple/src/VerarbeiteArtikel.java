import java.util.*;
public class VerarbeiteArtikel {
	
	public void ausgeben(ArrayList<Artikel> liste) {
		for (Artikel art: liste) {
			art.print();
			System.out.println("--------");
		}
	}
	
	public ArrayList<Artikel> einlesen (Scanner tastatur) {
		ArrayList<Artikel> liste = new ArrayList<Artikel>();
		Artikel art = null;
		String eingabe = "";
		
		do {
			art = artikelEinlesen(tastatur);
			if (art != null) {
				liste.add(art);
			}
			
			System.out.print("Weiter/Ende?");
			eingabe = tastatur.next();
		}while (eingabe.equals("Weiter"));
		
		return liste;
	}
	
	private Artikel artikelEinlesen(Scanner tastatur) {
		Artikel art = null;
		System.out.println("Welche Artikel-Art?");
		System.out.print("KaufArtikel/LeihArtikel? ");
		String eingabe = tastatur.next(); // Artikelart eintippen
		
		if (eingabe.equals("KaufArtikel") || eingabe.equals("LeihArtikel")) {
			System.out.print("Artikelname: ");
			String name = tastatur.next();
			System.out.print("Artikelnummer: ");
			int nummer = tastatur.nextInt();
			
			switch(eingabe) {
			case "KaufArtikel": 
				System.out.print("Kaufpreis: ");
				double preis = tastatur.nextDouble();
				art = new KaufArtikel(name,nummer,preis);
				break;
				
			case "LeihArtikel": 
				System.out.print("Leihgebuehr: ");
				double leih = tastatur.nextDouble();
				System.out.print("Wie viele Tage? ");
				int tage = tastatur.nextInt();
				art = new LeihArtikel(name,nummer,leih,tage);
				
				break;
			
			} // end switch
			
		} // end if
		return art;
	} // end method
} // end class
