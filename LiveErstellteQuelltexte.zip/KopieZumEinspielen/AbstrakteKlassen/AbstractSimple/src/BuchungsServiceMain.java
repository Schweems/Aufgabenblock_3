
public class BuchungsServiceMain {

	public static void main(String[] args) {
		BuchungsService b = new MietwagenService("Schrottlaube & Co. KG",10,1);
		
		System.out.println(b.rechnung());

	}

}
