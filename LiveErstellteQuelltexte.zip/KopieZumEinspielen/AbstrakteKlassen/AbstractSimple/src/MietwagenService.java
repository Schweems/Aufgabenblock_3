
public class MietwagenService
		extends BuchungsService {
	
	private int gebuchteTage;
	private int kategorie;
	
	public MietwagenService(String anbieter, int gebuchteTage, int kategorie) {
		super(anbieter);
		this.gebuchteTage = gebuchteTage;
		this.kategorie = kategorie;
	}

	@Override
	public double preis() {
		double preis = 0.0;
		if (kategorie == 0) {
			preis = 35.50 * gebuchteTage;
		}
		else if (kategorie >= 1) {
			preis = 43.50 * gebuchteTage;
		}
		return preis;
	}

	@Override
	public String rechnung() {
		String rech = "";
		rech += "Rechnung von " + getAnbieter()  + "\n";
		rech += "Gebuchte Tage: " + gebuchteTage + "\n";
		rech += "===========================\n";
		rech += "Endpreis: " + preis() + "EUR" + "\n";
		return rech;
	}
	
	public int getKategorie() {
		return kategorie;
	}
	
	public int getGebuchteTage() {
		return gebuchteTage;
	}
	

}
