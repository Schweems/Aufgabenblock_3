
public class KaufArtikel extends Artikel {
	private double preis;
	
	public KaufArtikel(String artikelName, int artikelNummer, double preis) {
		super(artikelName,artikelNummer);
		this.preis = preis;
	}
	
	public void setPreis(double preis) {this.preis = preis;}
	public double getPreis() {return preis;}
	
	@Override
	public void print() {
		System.out.println("Artikel: " + this);
		System.out.println("Preis: " + this.preis);
	}
	
}
