
public abstract class AusleihService extends BuchungsService{
	private String artikel;
	
	public AusleihService(String anbieter, String artikel) {
		super(anbieter);
		this.artikel = artikel;
	}
	
	// Wir wissen hier noch nicht genau, WAS wir verleihen.
	// Daher muss preis() und rechnung() in einer Enkelklasse
	// implementiert werden!
	
}
