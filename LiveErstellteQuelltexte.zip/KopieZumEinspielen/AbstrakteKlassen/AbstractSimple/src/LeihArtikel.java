
public class LeihArtikel extends Artikel {
	private double leihGebuehr;
	private int tageGeliehen;
	
	public LeihArtikel(String artikelName, int artikelNummer, double leihGebuehr, int tageGeliehen) {
		super(artikelName,artikelNummer);
		this.leihGebuehr = leihGebuehr;
		this.tageGeliehen = tageGeliehen;
	}
	
	public void setLeihGebuehr(double leihGebuehr) {
		this.leihGebuehr = leihGebuehr;
	}
	
	public void setTageGeliehen(int tageGeliehen) {
		this.tageGeliehen = tageGeliehen;
	}
	
	public double getLeihGebuehr( ) {
		return leihGebuehr;
	}
	
	public int getTageGeliehen() {
		return tageGeliehen;
	}
	
	@Override
	public void print() {
		System.out.println("Artikel: " + this);
		System.out.println("Tage geliehen: " + tageGeliehen);
		System.out.println("Leihgebuehr: " + leihGebuehr);
	}

}
