
public interface IGambler {
	
	String getNameOfGame();
	
	default boolean hasWon() {
		return true;
	}

}
