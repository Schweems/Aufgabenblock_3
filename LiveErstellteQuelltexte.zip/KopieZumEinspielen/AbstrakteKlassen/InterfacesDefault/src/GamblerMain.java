
public class GamblerMain {

	public static void main(String[] args) {
	
		
		Winner w = new Winner();
		
		Dicer d = new Dicer();
		
		for (int i=1; i<=10; i++) {
			System.out.println("Runde " + i +":");
		
			System.out.println("Winner w hat Ergebnis: " + w.hasWon());
			System.out.println("Dicer d hat Ergebnis: " + d.hasWon());
			System.out.println("-------------");
			
		}

	}

}
