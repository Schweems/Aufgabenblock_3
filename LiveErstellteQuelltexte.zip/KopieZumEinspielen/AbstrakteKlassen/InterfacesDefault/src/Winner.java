
public class Winner implements IGambler {
	
	private final String nameOfGame = "Winner takes all!";
	
	@Override 
	public String getNameOfGame() {
		return nameOfGame;
	}
	// Fuer hasWon() wird die Default-Implementierung genommen
}
