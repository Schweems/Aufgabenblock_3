import java.util.Random;

public class Dicer implements IGambler {
	
	private int value;
	
	@Override
	public String getNameOfGame() {
		return this.getClass().getName();
	}
	
	@Override
	public boolean hasWon() {
		Random r = new Random();
		
		// nextInt() liefert Wert zwischen 0 und < 6
		value = r.nextInt(6) + 1;
		
		return (value == 6);
	}

}
