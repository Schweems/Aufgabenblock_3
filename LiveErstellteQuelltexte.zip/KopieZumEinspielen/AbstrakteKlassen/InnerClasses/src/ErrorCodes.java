
public class ErrorCodes {
	public static class IOError {
		public static final int NO_PRIVILEGE=1;
		public static final int DISK_FULL = 2;
		
	}
	
	public static class OSError {
		public static final int PROCESS_HANGUP=3;
	}

}
