
public class ErrorMain {

	public static void main(String[] args) {
		System.out.println("No Privilege: " + ErrorCodes.IOError.NO_PRIVILEGE);

	}

}
