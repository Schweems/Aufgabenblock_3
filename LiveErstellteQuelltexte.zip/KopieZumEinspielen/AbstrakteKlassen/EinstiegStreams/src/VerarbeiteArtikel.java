import java.util.ArrayList;

public interface VerarbeiteArtikel {
	
	public ArrayList<Artikel> einlesen () ;
	public void ausgeben(ArrayList<Artikel> liste);

}
