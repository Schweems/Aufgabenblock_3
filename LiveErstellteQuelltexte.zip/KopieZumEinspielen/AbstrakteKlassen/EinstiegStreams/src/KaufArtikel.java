
public class KaufArtikel extends Artikel {
	private double preis;
	
	public KaufArtikel(String artikelName, int artikelNummer, double preis) {
		super(artikelName,artikelNummer);
		this.preis = preis;
	}
	
	public void setPreis(double preis) {this.preis = preis;}
	public double getPreis() {return preis;}
	
	@Override
	public String toString() {
		String erg = this.getClass().getName() + "\n";
		erg += this.getArtikelName() + "\n";
		erg += this.getArtikelNummer() + "\n";
		erg += this.preis + "\n";
		
		return erg;
	}
	
}
