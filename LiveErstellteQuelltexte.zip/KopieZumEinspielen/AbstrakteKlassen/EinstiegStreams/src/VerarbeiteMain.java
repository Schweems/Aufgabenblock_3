import java.util.*;
public class VerarbeiteMain {

	public static void main(String[] args) {
		VerarbeiteArtikel worker =
				new VerarbeiteArtikelTextDateiAnzahl("datei.txt","kopie.txt");
		ArrayList <Artikel> liste = worker.einlesen();
		worker.ausgeben(liste);
	}

}
