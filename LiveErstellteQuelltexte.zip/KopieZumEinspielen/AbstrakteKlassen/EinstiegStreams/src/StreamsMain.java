import java.io.*;
public class StreamsMain {

	public static void main(String[] args)
			throws IOException {
		// 1. Streams oeffnen
		/*BufferedReader in = new 
				BufferedReader(new FileReader("datei.txt"));
		
		PrintWriter out = new PrintWriter(new FileWriter("datei2.txt"));
		
		// 2. Daten verarbeiten aus den Streams
		String gelesen = in.readLine();
		out.println("Gelesen: " + gelesen);
		
		// 3. Streams wieder schliessen
		in.close();
		out.close();*/
		
		Kopierer worker = new Kopierer();
		String inhalt = worker.dateiLesen("datei.txt");
		worker.dateiSchreiben("dateineu.txt", inhalt);
	
	}

}
