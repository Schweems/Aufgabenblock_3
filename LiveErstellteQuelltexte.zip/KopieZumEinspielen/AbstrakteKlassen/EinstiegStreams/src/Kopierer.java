import java.io.*;
public class Kopierer {
	
	public String dateiLesen(String dateiname) 
			throws IOException {
		
		String input = "";
		String zeile;
		BufferedReader in = new 
				BufferedReader(new FileReader(dateiname));
		
		while((zeile=in.readLine()) != null ) {
			input += zeile +"\n";
		}
		
		in.close();
		return input;
	}
	
	public void dateiSchreiben(String dateiname, String inhalt) 
			throws IOException {
		BufferedWriter out = new BufferedWriter(new FileWriter(dateiname));
		
		out.write(inhalt);
		
		out.close();
	}

}
