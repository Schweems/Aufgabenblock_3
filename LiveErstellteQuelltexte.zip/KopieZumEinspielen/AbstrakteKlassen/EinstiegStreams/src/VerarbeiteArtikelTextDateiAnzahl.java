import java.util.*;
import java.io.*;
public class VerarbeiteArtikelTextDateiAnzahl implements VerarbeiteArtikel {
	private String dateiLesen;
	private String dateiSchreiben;
	
	public VerarbeiteArtikelTextDateiAnzahl(String dateiLesen, String dateiSchreiben) {
		this.dateiLesen = dateiLesen;
		this.dateiSchreiben = dateiSchreiben;
	}
	
	public void ausgeben(ArrayList<Artikel> liste) {
		try {
			PrintWriter p = new PrintWriter(new FileWriter(dateiSchreiben));
			p.println(liste.size());
			for (Artikel art : liste) {
				p.println(art.getClass().getName());
				p.print(art);
			}
			p.close();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
	@Override
	public ArrayList<Artikel> einlesen () {
		ArrayList<Artikel> liste = new ArrayList<Artikel>();
		
		Artikel art=null;
		try {
			BufferedReader file = new BufferedReader(new FileReader(dateiLesen));
			int anzahl = Integer.parseInt(file.readLine());
			for (int i=0;i < anzahl; i++) {
				art = artikelEinlesen(file);
				if (art != null) {
					liste.add(art);
				}
				else {
					System.out.println("Nix mehr gelesen!");
				}
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return liste;
	}
	
	private Artikel artikelEinlesen(BufferedReader datei) throws IOException {
		Artikel art = null;
		String eingabe = datei.readLine();
		System.out.println("Gelesen: " + eingabe);
		
		if (eingabe != null) {
			String artname = datei.readLine();
			int artnr = Integer.parseInt(datei.readLine());
			if (eingabe.equals("KaufArtikel")) {
				double preis = Double.parseDouble(datei.readLine());
				art = new KaufArtikel(artname,artnr,preis);
			}
			else if(eingabe.equals("LeihArtikel")) {
				double leihgebuehr = Double.parseDouble(datei.readLine());
				int anzTage = Integer.parseInt(datei.readLine());
				art = new LeihArtikel(artname,artnr,leihgebuehr, anzTage);
			}
		}
		
		return art;
	} // end method
} // end class
