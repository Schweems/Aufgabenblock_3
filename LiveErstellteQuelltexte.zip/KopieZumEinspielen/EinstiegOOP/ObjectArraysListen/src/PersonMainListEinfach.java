import java.util.ArrayList;

public class PersonMainListEinfach {

	public static void main(String[] args) {

		// ArrayList<Person> pliste erzeugen
		ArrayList <Person> pliste =
				new ArrayList<Person> ();
		
		// Objekte erzeugen
		Person p1 = new Person("Erna");
		Person p2 = new Person("Hugo");
		
		// Objekte einhaengen
		pliste.add(p1);
		pliste.add(p2);
		
		// Liste mit Zaehlschleife: Achtung: nicht .length, sondern .size()
		for (int i=0; i< pliste.size() ;i++) {
			Person p = pliste.get(i); // Liefere Instanz an Pos. i
			System.out.println(p.getName());
		}
		System.out.println("--------------");
		
		for(Person p : pliste) {
			System.out.println("Mit Iterationsschleife: " + p.getName());
		}
		
		
		

	}

}
