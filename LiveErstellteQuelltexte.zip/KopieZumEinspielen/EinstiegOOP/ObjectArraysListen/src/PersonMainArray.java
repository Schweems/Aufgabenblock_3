import java.util.Scanner;
public class PersonMainArray {

	public static void main(String[] args) {
		Scanner tastatur = new Scanner(System.in);
		System.out.print("Anzahl Personen: ");
		int anz = tastatur.nextInt();
		
		// Schritt 1: Array fuer Personenreferenzen erzeugen
		//int [] arrInt = new int[anz];
		Person [] personen = new Person[anz];
		
		// Erzeugungs- und Belegungsschleife
		for(int i=0; i<personen.length; i++) {
			// Schritt 2: Objekt erzeugen
			System.out.print("Name: ");
			String name = tastatur.next();
			Person p = new Person(name);
			
			// Schritt 3: Referenz der Person ins Array haengen
			personen[i] = p;
		}
		
		for (Person p : personen) {
			System.out.println(p.getName());
		}
		
		for (int i=0; i<personen.length; i++) {
			Person p = personen[i];
			System.out.println(p.getName());
		}

		tastatur.close();
	}

}
