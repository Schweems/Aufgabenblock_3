import java.util.*;
public class PersonMainListe {

	public static void main(String[] args) {
		Scanner tastatur = new Scanner(System.in);
		ArrayList<Person> personen = new ArrayList<Person>();
		System.out.print("Wie viele?");
		int anzahl = tastatur.nextInt();
		
		for(int i=0; i<anzahl; i++) {
			System.out.print("Naechster: ");
			//String name = tastatur.next();
			//Person p = new Person(name);
			Person p = new Person(tastatur.next());
			personen.add(p);
		}
		
		for (Person p : personen) {
			System.out.println("Person: " + p.getName());
		}
		personen.remove(1);
		for (Person p : personen) {
			System.out.println("Person jetzt: " + p.getName());
		}
		tastatur.close();
	}

}
