
public class Buch {
	private String titel;
	private String autor;
	
	public Buch(String titel, String autor) {
		this.titel = titel;
		this.autor = autor;
	}
	
	public void print () {
		System.out.println(titel+": " +autor);
	}

}
