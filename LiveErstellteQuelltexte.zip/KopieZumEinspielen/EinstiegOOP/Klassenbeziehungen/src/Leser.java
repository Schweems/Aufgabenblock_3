import java.util.ArrayList;
public class Leser {
	private String name;
	public Buch liest;
	public ArrayList<Buch> besitzt;
	
	public Leser(String name, Buch liest, ArrayList<Buch> besitzt) {
		this.name=name;
		this.liest = liest;
		this.besitzt = besitzt;
	}
	
	public void print() {
		System.out.println(name + " liest: ");
		liest.print();
		
		System.out.println(name + " besitzt: ");
		for (Buch b : besitzt) {
			b.print();
		}
	}
}
