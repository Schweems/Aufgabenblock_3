
public class BuchMain {

	public static void main(String[] args) {
		Buch buch1 = new Buch();
		buch1.print();
		
		Buch buch2 = new Buch("Grauen von Eclipse","Matecki");
		buch2.print();
		
		String b1Titel = buch1.getTitel();
		System.out.println("Buch 1 Titel: " + b1Titel);
		buch1.setTitel("Abwasch im Weltraum");
		buch1.setAutor("Stefan Sp�lberg");
		buch1.print();
		// buch2.titel = "Enjoy Eclipse";
		//buch2.print();
		//Buch buch3 = buch2;
		Buch buch3 = new Buch(buch2);
		buch3.print();
		
		String autor = buch1.getAutor();
		autor += " und Roland Emmelich";
		buch1.setAutor(autor);
		buch1.print();
		// Hier wird automatisch toString() aufgerufen
		System.out.println(buch3);

	}

}
