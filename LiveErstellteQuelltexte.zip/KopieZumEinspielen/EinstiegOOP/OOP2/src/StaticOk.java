
public class StaticOk {
	public static final double kelvinNull = -273.15;
	
	public static double gradCelsius(double kelvin) {
		double celsius = kelvin + kelvinNull;
		return celsius;
	}

}
