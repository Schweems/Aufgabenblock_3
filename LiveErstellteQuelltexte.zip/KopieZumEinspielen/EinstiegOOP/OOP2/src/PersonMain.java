
public class PersonMain {

	public static void main(String[] args) {
		Person p = new Person("Erna");
		Person q = new Person("Hugo");
		
		System.out.println("p: " + p.getName());
		System.out.println("q: " + q.getName());
		
		Person.name = "Hugo2";
		System.out.println("Name: " + Person.getName());
		System.out.println("q: " + q.getName());
	}

}
