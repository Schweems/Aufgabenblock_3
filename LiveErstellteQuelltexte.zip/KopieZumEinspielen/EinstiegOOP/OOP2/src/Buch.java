
public class Buch {
	private String titel;
	private String autor;
	// Standardkonstruktor
	public Buch() {
		this.titel = "abc in xyz";
		this.autor = "anonymous";
	}
	
	// Voll qualifizierte Konstruktor
	public Buch (String titel, String autor) {
		this.titel = titel;
		this.autor = autor;
	}
	
	// Kopierkonstruktor (Copy Constructor)
	public Buch(Buch b) {
		this.titel = b.getTitel();
		this.autor = b.getAutor();
	}
	
	public String getTitel() {
		return this.titel;
	}
	
	public String getAutor() {
		return this.autor;
	}
	
	public void setAutor(String autor) {
		this.autor = autor;
	}
	
	public void setTitel(String titel) {
		this.titel = titel;
	}
	public void print() {
		//System.out.println("Titel: " +this.titel);
		//System.out.println("Autor: " + this.autor);
		String ausgabe = toString();
		System.out.println(ausgabe);
	}
	
	public String toString() {
		String erg = "[Autor: " +autor + " Titel: " + titel + "]";
		return erg;
	}
	
	
}
