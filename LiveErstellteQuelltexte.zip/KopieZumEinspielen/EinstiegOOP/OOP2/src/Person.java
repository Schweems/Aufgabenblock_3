
public class Person {
	public static String name;
	
	public Person(String name) {
		this.name = name;
	}
	
	public static String getName() {
		return name;
	}
	

}
