import java.util.Locale;

public class StaticMainTest {
	/*public  void hello() {
		System.out.println("Grmpf!");
	}*/

	public static void main(String[] args) {
		System.out.println("PI: " + Math.PI);
		
		double kelv = 25.6;
		double cels = StaticOk.gradCelsius(kelv);
		Locale.setDefault(Locale.ENGLISH); // Punkt statt Komma ausgeben
		
		// Zahlen mit 2 Nachkommastellen als float oder double ausgeben
		System.out.printf("Celsius: %.2f von Kelvin: %.2f" , cels,kelv);
		
		//StaticMainTest worker = new StaticMainTest();
		//worker.hello();

	}

}
