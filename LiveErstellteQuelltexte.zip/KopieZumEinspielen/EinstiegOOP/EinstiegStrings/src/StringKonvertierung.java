
public class StringKonvertierung {

	public static void main(String[] args) {
		int iWert = 12;
		double dWert = 1.5;
		String iString2 = "345";
		String bitString = "101";
		String dString2 = "22.5";
		
		String iString = String.valueOf(iWert); // Liefert Ziffernfolge "12"
		String dString = String.valueOf(dWert); // Liefert Zeichenfolge "1.5"
		
		int iwert2 = Integer.parseInt(iString2); // liefert 345
		iwert2++;
		System.out.println("iWert2: " + iwert2);
		
		int iWert3 = Integer.parseInt(bitString,2); // Dualzahl
		System.out.println("iWert3: " +iWert3);
		
		double dWert2 = Double.parseDouble(dString2);
		System.out.println("dWert2: " + dWert2);
		
		
	}

}
