
public class Args {

	public static void main(String[] args) {
		System.out.println("Anzahl Parameter: " + args.length);
		int summe = 0;
		for (String s : args) {
			System.out.println("s: " + s);
			int wert = Integer.parseInt(s);
			summe += wert;
			
		}
		
		System.out.println("Summe: " + summe);

	}

}
