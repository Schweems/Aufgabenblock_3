
public class StringMainAbfragen {

	public static void main(String[] args) {
		String s1 = new String("Hallo");
		String s2 = new String("Halloooooo");
		int [] arr = {11,6,8,23};
		
		char c = s1.charAt(1);
		System.out.println("Zeichen 1: " + c);
		
		int lenArr = arr.length;
		System.out.println("Laenge Array: " + lenArr);
		
		int lenStr = s1.length();
		System.out.println("Laenge String: " + lenStr);
		
		if (s1.startsWith("Ha")) {
			System.out.println("Startet mit Ha");
		}
		
		int posO = s2.indexOf('o');
		System.out.println("Position erstes o: " +posO);
		
		int posUx = s2.indexOf("ux");
		System.out.println("Position erstes ux: " + posUx);
		
		int posZahl = s2.indexOf('a',5);
		System.out.println("Position erstes a ab Pos. 5: " + posZahl);
		
		String sub = s2.substring(2);
		System.out.println("SubString ab 2: " + sub);

	}

}
