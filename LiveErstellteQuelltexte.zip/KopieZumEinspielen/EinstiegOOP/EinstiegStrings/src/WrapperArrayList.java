import java.util.*;
public class WrapperArrayList {

	public static void main(String[] args) {
		ArrayList<Integer> liste = new ArrayList<Integer>();
		Scanner tastatur = new Scanner(System.in);
		System.out.print("Wie viele? ");
		int anz = tastatur.nextInt();
		for (int i=0; i<anz; i++) {
			System.out.print("Naechster: ");
			int wert = tastatur.nextInt(); // Wert elementaren Typs einlesen ...
			// ... und in Liste aus Wrapper-Referenzen einh�ngen
			liste.add(wert);	
		}
		System.out.println("------------ Ausgabe -------------");
		// liste ist typisiert auf Integer. ix ist typisiert auf int.
		// --> Rueckkonvertierung Integer --> int erfolgt auch hier 
		// automatisch.
		for (int ix : liste) {
			System.out.println("ix: " + ix);
		}
		
		
		tastatur.close();
	}

}
