import java.util.*;
public class StringSplitting {

	public static void main(String[] args) {
		Scanner tastatur = new Scanner(System.in);
		System.out.print("Ganzzahlen mit Leerzeichen oder TAB getrennt eingeben: ");
		String zeile = tastatur.nextLine();
		String [] elemente = zeile.split("[ \t]+");
		int summe = 0;
		// Array-Elemente ausgeben
		for (int i=0; i<elemente.length; i++) {
			System.out.println("e: " + elemente[i]);
			summe += Integer.parseInt(elemente[i]);
		}
		System.out.println("summe: " + summe);
		tastatur.close();
	}

}
