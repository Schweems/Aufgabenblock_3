
public class StringMain {

	public static void main(String[] args) {
		char x='X';
		String s = "Erna";
		String u = "Erna";
		String t = new String("Erna");
		
		if (s == u) {
			System.out.println("s und u gleich!");
		}
		else {
			System.out.println("s und u ungleich!");
		}
		
		if (s == t) {
			System.out.println("s und t gleich!");
		}
		else {
			System.out.println("s und t ungleich!");
		}
		
		if(s.equals(t)) {
			System.out.println("equals: s und t gleich!");
		}
		else {
			System.out.println("equals: s und t ungleich!");
		}
			

	}

}
