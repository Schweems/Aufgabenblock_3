import java.util.*;
public class StringMainSwitch {

	public static void main(String[] args) {
		Scanner tastatur = new Scanner(System.in);
		System.out.print("Name: ");
		String t = tastatur.next();
		
		switch(t) {
		case "Erna": System.out.println("Hallo Erna"); break;
		case "Hugo": System.out.println("Hallo Hugo"); break;
		default: System.out.println("Keiner von beiden!");
		}
		
		tastatur.close();
	}

}
